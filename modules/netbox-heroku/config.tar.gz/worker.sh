#!/bin/sh

exec /opt/netbox/netbox/manage.py rqworker
